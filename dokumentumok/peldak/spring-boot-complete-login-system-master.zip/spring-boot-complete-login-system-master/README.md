# spring-boot
Login and Registration Example Project with Spring Boot Security

This is a template for a simple and informational Login and CRUD WebAPP. It coding in Spring-Hibernate-Maven using database like MySQL with the design pattern Model-View-Controller (MVC).

# Prerequisites

JDK 1.8
Maven 3

# Stack
spring Security
Spring Boot
Spring Data JPA
Maven
MYSQL

# RUN
mvn clean spring-boot:run
